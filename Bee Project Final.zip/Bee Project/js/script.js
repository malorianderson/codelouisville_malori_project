$(document).ready (function() {
	// quote list
	var factList = [{
		fact: "this is fact no. 1"
	},
	{
		fact: "this is fact no. 2."
	},
	{
		fact: "this is fact no. 3."
	},
	{
		fact: "this is fact no. 4."
	}
	];


	 var newFact = "";
	  $(".btn").click(function() {
	event.preventDefault();
		
	    var facts = factList.length;
	    //used array.length and returned random number
                  var ranFact = Math.floor(Math.random() * (4-1) + 1);
                  console.log(ranFact);

	   
	      //Pulls quote using random number as sub-array selector
                  newFact = factList[ranFact].fact;

                 //remove previous fact
                  $(".factAdd").remove();
                  //append new fact to html
                  $("#btnContainer").append("<p class=\"factAdd\">"+ newFact +"</p>");

	    });

	});